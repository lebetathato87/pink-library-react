import { useState, useEffect } from "react";

function BookForm({ onSave, editingBook, onCancel }) {
  const [book, setBook] = useState({
    title: "",
    author: "",
    genre: "",
    isbn: "",
    quantity: 1
  });

  useEffect(() => {
    if (editingBook) {
      setBook(editingBook);
    } else {
      setBook({
        title: "",
        author: "",
        genre: "",
        isbn: "",
        quantity: 1
      });
    }
  }, [editingBook]);

  function handleChange(e) {
    setBook({
      ...book,
      [e.target.name]: e.target.value
    });
  }

  function handleSubmit(e) {
    e.preventDefault();

    if (
      !book.title.trim() ||
      !book.author.trim() ||
      !book.genre.trim() ||
      !book.isbn.trim() ||
      Number(book.quantity) < 0
    ) {
      alert("Please fill in all fields correctly.");
      return;
    }

    onSave({
      ...book,
      title: book.title.trim(),
      author: book.author.trim(),
      genre: book.genre.trim(),
      isbn: book.isbn.trim(),
      quantity: Number(book.quantity)
    });

    setBook({
      title: "",
      author: "",
      genre: "",
      isbn: "",
      quantity: 1
    });
  }

  return (
    <form onSubmit={handleSubmit} className="form">
      <h2>{editingBook ? "Edit Book" : "Add New Book"}</h2>

      <input
        type="text"
        name="title"
        placeholder="Book Title"
        value={book.title}
        onChange={handleChange}
        required
      />

      <input
        type="text"
        name="author"
        placeholder="Author"
        value={book.author}
        onChange={handleChange}
        required
      />

      <input
        type="text"
        name="genre"
        placeholder="Genre"
        value={book.genre}
        onChange={handleChange}
        required
      />

      <input
        type="text"
        name="isbn"
        placeholder="ISBN"
        value={book.isbn}
        onChange={handleChange}
        required
      />

      <input
        type="number"
        name="quantity"
        placeholder="Quantity"
        min="0"
        value={book.quantity}
        onChange={handleChange}
        required
      />

      <button type="submit">
        {editingBook ? "Update Book" : "Add Book"}
      </button>

      {editingBook && (
        <button type="button" onClick={onCancel}>
          Cancel
        </button>
      )}
    </form>
  );
}

export default BookForm;
import { useState, useEffect } from "react";

function UserForm({ onSave, editingUser, onCancel }) {
  const [user, setUser] = useState({
    name: "",
    membershipId: "",
    email: "",
    role: "Member"
  });

  useEffect(() => {
    if (editingUser) {
      setUser({
        name: editingUser.name || "",
        membershipId: editingUser.membershipId || "",
        email: editingUser.email || "",
        role: editingUser.role || "Member"
      });
    } else {
      setUser({
        name: "",
        membershipId: "",
        email: "",
        role: "Member"
      });
    }
  }, [editingUser]);

  function handleChange(e) {
    setUser({
      ...user,
      [e.target.name]: e.target.value
    });
  }

  function handleSubmit(e) {
    e.preventDefault();

    if (
      !user.name.trim() ||
      !user.membershipId.trim() ||
      !user.email.trim()
    ) {
      alert("Please fill in all required fields.");
      return;
    }

    onSave({
      ...user,
      name: user.name.trim(),
      membershipId: user.membershipId.trim(),
      email: user.email.trim().toLowerCase()
    });

    setUser({
      name: "",
      membershipId: "",
      email: "",
      role: "Member"
    });
  }

  return (
    <form onSubmit={handleSubmit} className="form">
      <h2>{editingUser ? "Edit User" : "Register User"}</h2>

      <input
        type="text"
        name="name"
        placeholder="Full Name"
        value={user.name}
        onChange={handleChange}
        required
      />

      <input
        type="text"
        name="membershipId"
        placeholder="Membership ID"
        value={user.membershipId}
        onChange={handleChange}
        required
      />

      <input
        type="email"
        name="email"
        placeholder="Email Address"
        value={user.email}
        onChange={handleChange}
        required
      />

      <select
        name="role"
        value={user.role}
        onChange={handleChange}
      >
        <option value="Member">Member</option>
        <option value="Admin">Admin</option>
      </select>

      <button type="submit">
        {editingUser ? "Update User" : "Add User"}
      </button>

      {editingUser && (
        <button type="button" onClick={onCancel}>
          Cancel
        </button>
      )}
    </form>
  );
}

export default UserForm;
function BookList({ books, onEdit, onDelete }) {
  return (
    <div className="book-list">
      <h2>Library Books</h2>

      {books.length === 0 ? (
        <p>No books available.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Title</th>
              <th>Author</th>
              <th>Genre</th>
              <th>ISBN</th>
              <th>Quantity</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {books.map((book) => (
              <tr key={book.id}>
                <td>{book.title}</td>
                <td>{book.author}</td>
                <td>{book.genre}</td>
                <td>{book.isbn}</td>

                <td>
                  {book.quantity}

                  {book.quantity < 2 && (
                    <span style={{ color: "red" }}>
                      {" "}Low Stock
                    </span>
                  )}
                </td>

                <td>
                  <button onClick={() => onEdit(book)}>
                    Edit
                  </button>

                  <button onClick={() => onDelete(book.id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default BookList;
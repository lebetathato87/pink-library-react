import { useState } from "react";

function TransactionForm({ books, onTransaction }) {
  const [bookId, setBookId] = useState("");
  const [type, setType] = useState("Borrow");
  const [quantity, setQuantity] = useState(1);

  function handleSubmit(e) {
    e.preventDefault();

    if (!bookId || Number(quantity) < 1) {
      alert("Please select a book and enter a valid quantity.");
      return;
    }

    const selectedBook = books.find(
      (book) => String(book.id) === String(bookId)
    );

    if (!selectedBook) {
      alert("Book not found.");
      return;
    }

    if (
      type === "Borrow" &&
      Number(quantity) > selectedBook.quantity
    ) {
      alert("There are not enough copies available.");
      return;
    }

    onTransaction({
      bookId,
      type,
      quantity: Number(quantity)
    });

    setBookId("");
    setType("Borrow");
    setQuantity(1);
  }

  return (
    <form onSubmit={handleSubmit} className="form">
      <h2>Book Transactions</h2>

      <label>Select Book</label>

      <select
        value={bookId}
        onChange={(e) => setBookId(e.target.value)}
        required
      >
        <option value="">Choose a book</option>

        {books.map((book) => (
          <option key={book.id} value={book.id}>
            {book.title} ({book.quantity} available)
          </option>
        ))}
      </select>

      <label>Transaction Type</label>

      <select
        value={type}
        onChange={(e) => setType(e.target.value)}
      >
        <option value="Borrow">Borrow Book</option>
        <option value="Add Stock">Add Stock</option>
      </select>

      <label>Quantity</label>

      <input
        type="number"
        min="1"
        value={quantity}
        onChange={(e) => setQuantity(e.target.value)}
        required
      />

      <button type="submit">
        Record Transaction
      </button>
    </form>
  );
}

export default TransactionForm;
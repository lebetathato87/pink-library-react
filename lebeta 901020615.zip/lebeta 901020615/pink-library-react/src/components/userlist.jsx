function UserList({ users, onEdit, onDelete }) {
  return (
    <div className="user-list">
      <h2>Registered Users</h2>

      {users.length === 0 ? (
        <p>No users registered yet.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Membership ID</th>
              <th>Email</th>
              <th>Role</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td>{user.name}</td>
                <td>{user.membershipId}</td>
                <td>{user.email}</td>
                <td>{user.role}</td>

                <td>
                  <button onClick={() => onEdit(user)}>
                    Edit
                  </button>

                  <button onClick={() => onDelete(user.id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default UserList;
function Dashboard({ books, users, transactions }) {
  const totalBooks = books.reduce(
    (total, book) => total + Number(book.quantity),
    0
  );

  const lowStockBooks = books.filter(
    (book) => Number(book.quantity) < 2
  );

  return (
    <div className="page">
      <h1>Library Dashboard 💗</h1>

      <div className="dashboard-cards">
        <div className="card">
          <h3>Total Book Titles</h3>
          <p>{books.length}</p>
        </div>

        <div className="card">
          <h3>Available Copies</h3>
          <p>{totalBooks}</p>
        </div>

        <div className="card">
          <h3>Registered Users</h3>
          <p>{users.length}</p>
        </div>

        <div className="card">
          <h3>Transactions</h3>
          <p>{transactions.length}</p>
        </div>
      </div>

      <h2>Low Stock Books</h2>

      {lowStockBooks.length === 0 ? (
        <p>All books have enough stock.</p>
      ) : (
        <ul>
          {lowStockBooks.map((book) => (
            <li key={book.id}>
              {book.title} — {book.quantity} copies remaining
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default Dashboard;
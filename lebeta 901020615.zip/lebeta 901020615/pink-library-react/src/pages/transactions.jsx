import TransactionForm from "../components/TransactionForm";

function Transactions({ books, onTransaction, transactions }) {
  return (
    <div className="page">
      <h1>Book Transactions 🔄</h1>

      <TransactionForm
        books={books}
        onTransaction={onTransaction}
      />

      <h2>Transaction History</h2>

      {transactions.length === 0 ? (
        <p>No transactions recorded yet.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Book</th>
              <th>Type</th>
              <th>Quantity</th>
              <th>Date</th>
            </tr>
          </thead>

          <tbody>
            {transactions.map((transaction) => (
              <tr key={transaction.id}>
                <td>{transaction.bookTitle}</td>
                <td>{transaction.type}</td>
                <td>{transaction.quantity}</td>
                <td>{transaction.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default Transactions;
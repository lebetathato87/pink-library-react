import { useState } from "react";
import UserForm from "../components/UserForm";
import UserList from "../components/UserList";

function Users({ users, onSave, onDelete }) {
  const [editingUser, setEditingUser] = useState(null);

  function handleSave(user) {
    onSave(user);
    setEditingUser(null);
  }

  return (
    <div className="page">
      <h1>User Management 👥</h1>

      <UserForm
        onSave={handleSave}
        editingUser={editingUser}
        onCancel={() => setEditingUser(null)}
      />

      <UserList
        users={users}
        onEdit={setEditingUser}
        onDelete={onDelete}
      />
    </div>
  );
}

export default Users;
import { useState } from "react";
import BookForm from "../components/BookForm";
import BookList from "../components/BookList";

function Books({ books, onSave, onDelete }) {
  const [editingBook, setEditingBook] = useState(null);

  function handleSave(book) {
    onSave(book);
    setEditingBook(null);
  }

  return (
    <div className="page">
      <h1>Book Management 📚</h1>

      <BookForm
        onSave={handleSave}
        editingBook={editingBook}
        onCancel={() => setEditingBook(null)}
      />

      <BookList
        books={books}
        onEdit={setEditingBook}
        onDelete={onDelete}
      />
    </div>
  );
}

export default Books;
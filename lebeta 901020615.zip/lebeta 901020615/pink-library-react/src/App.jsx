import { useEffect, useState } from 'react';
import { Link, Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom';

const starterBooks = [
  { id: 1, title: 'Things Fall Apart', author: 'Chinua Achebe', genre: 'Fiction', isbn: '9780385474542', quantity: 4 },
  { id: 2, title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', genre: 'Classic', isbn: '9780743273565', quantity: 1 },
  { id: 3, title: 'Purple Hibiscus', author: 'Chimamanda Ngozi Adichie', genre: 'Fiction', isbn: '9781616202415', quantity: 3 }
];
const starterUsers = [{ id: 1, name: 'Library Admin', membershipId: 'ADMIN001', email: 'admin@library.com', role: 'Admin' }];
const readStorage = (key, fallback) => {
  try { const value = localStorage.getItem(key); return value ? JSON.parse(value) : fallback; }
  catch { return fallback; }
};

function App() {
  const [books, setBooks] = useState(() => readStorage('MmemeLibraryBooks', starterBooks));
  const [users, setUsers] = useState(() => readStorage('MmemeLibraryUsers', starterUsers));
  const [transactions, setTransactions] = useState(() => readStorage('MmemeLibraryTransactions', []));
  const [loggedIn, setLoggedIn] = useState(() => sessionStorage.getItem('MmemeLibraryLogin') === 'yes');
  const [currentUser, setCurrentUser] = useState(() => readStorage('MmemeLibraryCurrentUser', starterUsers[0]));

  useEffect(() => localStorage.setItem('MmemeLibraryBooks', JSON.stringify(books)), [books]);
  useEffect(() => localStorage.setItem('MmemeLibraryUsers', JSON.stringify(users)), [users]);
  useEffect(() => localStorage.setItem('MmemeLibraryTransactions', JSON.stringify(transactions)), [transactions]);
  useEffect(() => localStorage.setItem('MmemeLibraryCurrentUser', JSON.stringify(currentUser)), [currentUser]);

  const login = (username, password) => {
    // Demo login for the assignment. Replace with server authentication in a real system.
    if (username.trim() === 'Thato Lebeta' && password === 'keaa2025') {
      const admin = users.find(user => user.role === 'Thato L') || starterUsers[0];
      setCurrentUser(admin); setLoggedIn(true); sessionStorage.setItem('MmemeLibraryLogin', 'yes'); return true;
    }
    const found = users.find(user => user.email.toLowerCase() === username.trim().toLowerCase() && password === user.membershipId);
    if (found) { setCurrentUser(found); setLoggedIn(true); sessionStorage.setItem('MmemeLibraryLogin', 'yes'); return true; }
    return false;
  };
  const logout = () => { setLoggedIn(false); sessionStorage.removeItem('MmemeLibraryLogin'); };

  const addTransaction = (book, type, amount, member = '') => {
    setTransactions(old => [{ id: Date.now(), bookTitle: book.title, type, amount, member: member || currentUser.name || 'Library Admin', date: new Date().toLocaleString() }, ...old]);
  };
  const saveBook = (data) => {
    const quantity = Math.max(0, Number(data.quantity) || 0);
    if (data.id) setBooks(old => old.map(book => book.id === data.id ? { ...data, quantity } : book));
    else setBooks(old => [...old, { ...data, id: Date.now(), quantity }]);
  };
  const deleteBook = id => { if (window.confirm('Delete this book?')) setBooks(old => old.filter(book => book.id !== id)); };
  const changeStock = (id, type, amount, member) => {
    const book = books.find(item => item.id === Number(id));
    const qty = Number(amount);
    if (!book || !Number.isInteger(qty) || qty < 1) return { error: 'Enter a whole number greater than zero.' };
    if (type === 'Borrow' && book.quantity < qty) return { error: 'There are not enough copies available.' };
    setBooks(old => old.map(item => item.id === book.id ? { ...item, quantity: item.quantity + (type === 'Add stock' ? qty : -qty) } : item));
    addTransaction(book, type, qty, member);
    return { success: true };
  };
  const saveUser = data => {
    const email = data.email.trim().toLowerCase();
    const memberId = data.membershipId.trim();
    if (users.some(user => user.id !== data.id && (user.email.toLowerCase() === email || user.membershipId.toLowerCase() === memberId.toLowerCase()))) {
      return 'Email or membership ID is already in use.';
    }
    if (data.id) setUsers(old => old.map(user => user.id === data.id ? { ...data, email, membershipId: memberId } : user));
    else setUsers(old => [...old, { ...data, id: Date.now(), email, membershipId: memberId }]);
    return '';
  };
  const deleteUser = id => { if (id === currentUser.id) { window.alert('You cannot delete the account currently in use.'); return; } if (window.confirm('Delete this user?')) setUsers(old => old.filter(user => user.id !== id)); };

  return <div className="app-shell">
    {loggedIn && <Header currentUser={currentUser} logout={logout} />}
    <Routes>
      <Route path="/login" element={loggedIn ? <Navigate to="/" replace /> : <Login onLogin={login} />} />
      <Route path="/" element={loggedIn ? <Dashboard books={books} transactions={transactions} users={users} /> : <Navigate to="/login" replace />} />
      <Route path="/books" element={loggedIn ? <Books books={books} saveBook={saveBook} deleteBook={deleteBook} changeStock={changeStock} /> : <Navigate to="/login" replace />} />
      <Route path="/transactions" element={loggedIn ? <Transactions books={books} transactions={transactions} changeStock={changeStock} /> : <Navigate to="/login" replace />} />
      <Route path="/users" element={loggedIn && currentUser.role === 'Admin' ? <Users users={users} saveUser={saveUser} deleteUser={deleteUser} /> : <Navigate to={loggedIn ? '/' : '/login'} replace />} />
      <Route path="*" element={<Navigate to={loggedIn ? '/' : '/login'} replace />} />
    </Routes>
    {loggedIn && <footer>Mmeme Community Library · Book management made simple</footer>}
  </div>;
}

function Header({ currentUser, logout }) {
  const location = useLocation();
  const links = [['/', 'Dashboard'], ['/books', 'Books'], ['/transactions', 'Transactions'], ['/users', 'Users']];
  return <header className="topbar"><Link to="/" className="brand"><span className="brand-icon">♡</span><span>Pink<span className="brand-light">Library</span><small>COMMUNITY LIBRARY SYSTEM</small></span></Link>
    <nav>{links.filter(([path]) => path !== '/users' || currentUser.role === 'Admin').map(([path, label]) => <Link key={path} className={location.pathname === path ? 'active' : ''} to={path}>{label}</Link>)}</nav>
    <div className="profile"><span className="avatar">{(currentUser.name || 'A').charAt(0).toUpperCase()}</span><span className="profile-name">{currentUser.name}<small>{currentUser.role}</small></span><button className="button button-outline button-small" onClick={logout}>Log out</button></div>
  </header>;
}

function Login({ onLogin }) {
  const [username, setUsername] = useState('Thato Lebeta'); const [password, setPassword] = useState('keaa2025'); const [error, setError] = useState(''); const navigate = useNavigate();
  const submit = e => { e.preventDefault(); if (!username.trim() || !password) { setError('Please fill in both fields.'); return; } if (onLogin(username, password)) navigate('/'); else setError('Login details are not correct.'); };
  return <main className="login-wrap"><section className="login-card"><div className="login-art"><div className="art-heart">♡</div><h1>A little more<br />knowledge. A lot<br />more possibility.</h1><p>Your neighbourhood library, all in one place.</p><div className="book-stack"><span>READ</span><span>LEARN</span><span>GROW</span></div></div><div className="login-form-area"><div className="mobile-logo">♡ PinkLibrary</div><p className="eyebrow">WELCOME BACK</p><h2>Sign in to your account</h2><p className="muted">Enter your details to manage the library.</p><form onSubmit={submit} className="form-stack"><label>Username or email<input value={username} onChange={e => setUsername(e.target.value)} placeholder="Enter username or email" /></label><label>Password<input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter password" /></label>{error && <p className="error">{error}</p>}<button className="button button-primary button-full">Sign in <span>→</span></button></form><div className="demo-box"><strong>Demo administrator login</strong><span>Username: <b>admin</b></span><span>Password: <b>library123</b></span></div><p className="login-note">Demo assignment login only. A real system should authenticate users on a server.</p></div></section></main>;
}

function PageTitle({ eyebrow, title, description, action }) { return <div className="page-title"><div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p className="muted">{description}</p></div>{action}</div>; }
function Dashboard({ books, transactions, users }) {
  const totalCopies = books.reduce((sum, book) => sum + Number(book.quantity), 0); const lowStock = books.filter(book => book.quantity < 2);
  return <main className="content"><PageTitle eyebrow="OVERVIEW" title="Library dashboard" description="Here is what is happening in your library today." action={<Link className="button button-primary" to="/books">＋ Add a book</Link>} />
    <div className="stats-grid"><Stat icon="▤" label="Book titles" value={books.length} tone="pink" /><Stat icon="▣" label="Total copies" value={totalCopies} tone="purple" /><Stat icon="♙" label="Registered users" value={users.length} tone="peach" /><Stat icon="↔" label="Transactions" value={transactions.length} tone="blue" /></div>
    <div className="dashboard-grid"><section className="panel"><div className="panel-heading"><div><h2>Book availability</h2><p className="muted">Current stock in your library</p></div><Link to="/books" className="text-link">Manage books →</Link></div>{books.length ? <div className="table-wrap"><table><thead><tr><th>Book title</th><th>Author</th><th>Genre</th><th>Copies</th><th>Status</th></tr></thead><tbody>{books.slice(0, 6).map(book => <tr key={book.id}><td className="book-name">{book.title}</td><td>{book.author}</td><td>{book.genre}</td><td><strong>{book.quantity}</strong></td><td><span className={`badge ${book.quantity < 2 ? 'badge-low' : 'badge-good'}`}>{book.quantity < 2 ? 'Low stock' : 'Available'}</span></td></tr>)}</tbody></table></div> : <Empty text="No books have been added yet." />}</section>
    <section className="panel"><div className="panel-heading"><div><h2>Needs attention</h2><p className="muted">Books with fewer than 2 copies</p></div><span className="count-pill">{lowStock.length}</span></div>{lowStock.length ? <div className="attention-list">{lowStock.map(book => <div className="attention-item" key={book.id}><span className="warning-icon">!</span><div><strong>{book.title}</strong><small>{book.author}</small></div><span className="stock-count">{book.quantity} left</span></div>)}</div> : <div className="success-empty"><span>✓</span><p>All books have enough stock.</p></div>}<Link to="/transactions" className="button button-soft button-full">Update stock</Link></section></div>
    <section className="panel recent-panel"><div className="panel-heading"><div><h2>Recent transactions</h2><p className="muted">Latest stock changes</p></div><Link to="/transactions" className="text-link">View all →</Link></div><TransactionTable transactions={transactions.slice(0, 5)} /></section>
  </main>;
}
function Stat({ icon, label, value, tone }) { return <div className="stat-card"><span className={`stat-icon ${tone}`}>{icon}</span><div><p>{label}</p><strong>{value}</strong></div><span className="stat-decoration">♡</span></div>; }
function Books({ books, saveBook, deleteBook, changeStock }) {
  const blank = { title: '', author: '', genre: '', isbn: '', quantity: 0 };
  const [form, setForm] = useState(blank); const [editing, setEditing] = useState(false); const [search, setSearch] = useState(''); const [message, setMessage] = useState('');
  const update = e => setForm({ ...form, [e.target.name]: e.target.value });
  const submit = e => { e.preventDefault(); if (!form.title.trim() || !form.author.trim() || !form.genre.trim() || !form.isbn.trim() || form.quantity === '') { setMessage('Please complete every field.'); return; } if (!Number.isInteger(Number(form.quantity)) || Number(form.quantity) < 0) { setMessage('Quantity must be a whole number and cannot be negative.'); return; } if (books.some(book => book.id !== form.id && book.isbn.trim().toLowerCase() === form.isbn.trim().toLowerCase())) { setMessage('That ISBN already exists.'); return; } saveBook({ ...form, title: form.title.trim(), author: form.author.trim(), genre: form.genre.trim(), isbn: form.isbn.trim(), quantity: Number(form.quantity) }); setForm(blank); setEditing(false); setMessage('Book saved successfully.'); };
  const edit = book => { setForm({ ...book }); setEditing(true); setMessage(''); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const stock = (book, type) => { const raw = window.prompt(type === 'Borrow' ? 'How many copies are being borrowed?' : 'How many copies are being added?', '1'); if (raw === null) return; const result = changeStock(book.id, type, raw, ''); setMessage(result.error || 'Stock updated successfully.'); };
  const filtered = books.filter(book => `${book.title} ${book.author} ${book.genre} ${book.isbn}`.toLowerCase().includes(search.toLowerCase()));
  return <main className="content"><PageTitle eyebrow="COLLECTION" title="Book management" description="Add, update, search and manage your book collection." />
    <section className="panel form-panel"><div className="panel-heading"><div><h2>{editing ? 'Update book details' : 'Add a new book'}</h2><p className="muted">Fields marked with * are required.</p></div>{editing && <button className="button button-outline" onClick={() => { setForm(blank); setEditing(false); setMessage(''); }}>Cancel edit</button>}</div><form className="book-form" onSubmit={submit}><label>Book title *<input name="title" value={form.title} onChange={update} required /></label><label>Author *<input name="author" value={form.author} onChange={update} required /></label><label>Genre *<input name="genre" value={form.genre} onChange={update} required /></label><label>ISBN *<input name="isbn" value={form.isbn} onChange={update} required /></label><label>Initial quantity *<input name="quantity" type="number" min="0" step="1" value={form.quantity} onChange={update} required /></label><div className="form-submit"><button className="button button-primary">{editing ? 'Save changes' : '＋ Add book'}</button></div></form>{message && <p className={message.includes('successfully') ? 'success-message' : 'error'}>{message}</p>}</section>
    <section className="panel"><div className="panel-heading list-heading"><div><h2>All books <span className="count-pill">{books.length}</span></h2><p className="muted">Edit book information or update stock.</p></div><input className="search-input" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search books..." /></div><div className="table-wrap"><table><thead><tr><th>Title / ISBN</th><th>Author</th><th>Genre</th><th>Copies</th><th>Actions</th></tr></thead><tbody>{filtered.map(book => <tr key={book.id}><td><span className="book-name">{book.title}</span><small className="table-sub">ISBN: {book.isbn}</small></td><td>{book.author}</td><td>{book.genre}</td><td><span className={`badge ${book.quantity < 2 ? 'badge-low' : 'badge-good'}`}>{book.quantity} copies</span></td><td><div className="row-actions"><button className="mini-button" onClick={() => edit(book)}>Edit</button><button className="mini-button" onClick={() => stock(book, 'Add stock')}>+ Stock</button><button className="mini-button" onClick={() => stock(book, 'Borrow')}>Borrow</button><button className="mini-button danger-text" onClick={() => deleteBook(book.id)}>Delete</button></div></td></tr>)}</tbody></table>{!filtered.length && <Empty text="No matching books found." />}</div></section>
  </main>;
}
function Transactions({ books, transactions, changeStock }) {
  const [bookId, setBookId] = useState(''); const [type, setType] = useState('Borrow'); const [amount, setAmount] = useState('1'); const [member, setMember] = useState(''); const [message, setMessage] = useState('');
  const submit = e => { e.preventDefault(); if (!bookId) { setMessage('Please choose a book.'); return; } if (type === 'Borrow' && !member.trim()) { setMessage('Enter the borrower or member name.'); return; } const result = changeStock(bookId, type, amount, member.trim()); if (result.error) setMessage(result.error); else { setMessage('Transaction saved successfully.'); setAmount('1'); setMember(''); } };
  return <main className="content"><PageTitle eyebrow="CIRCULATION" title="Stock transactions" description="Record new stock and borrowed copies. Every successful change is saved in the history." />
    <section className="panel transaction-form-panel"><div className="panel-heading"><div><h2>Record a transaction</h2><p className="muted">Stock will be updated automatically.</p></div><span className="round-icon">↔</span></div><form className="transaction-form" onSubmit={submit}><label>Select book<select value={bookId} onChange={e => setBookId(e.target.value)} required><option value="">Choose a book...</option>{books.map(book => <option key={book.id} value={book.id}>{book.title} ({book.quantity} available)</option>)}</select></label><label>Transaction type<select value={type} onChange={e => setType(e.target.value)}><option>Borrow</option><option>Add stock</option></select></label><label>Number of copies<input type="number" min="1" step="1" value={amount} onChange={e => setAmount(e.target.value)} required /></label>{type === 'Borrow' && <label>Borrower / member name<input value={member} onChange={e => setMember(e.target.value)} placeholder="Enter member's name" required /></label>}<button className="button button-primary">Save transaction</button></form>{message && <p className={message.includes('successfully') ? 'success-message' : 'error'}>{message}</p>}</section>
    <section className="panel"><div className="panel-heading"><div><h2>Transaction history</h2><p className="muted">A record of stock added and books borrowed.</p></div><span className="count-pill">{transactions.length} records</span></div><TransactionTable transactions={transactions} /></section>
  </main>;
}
function TransactionTable({ transactions }) { if (!transactions.length) return <Empty text="No transactions yet. They will appear here when stock is changed." />; return <div className="table-wrap"><table><thead><tr><th>Book</th><th>Type</th><th>Copies</th><th>Member / user</th><th>Date and time</th></tr></thead><tbody>{transactions.map(item => <tr key={item.id}><td className="book-name">{item.bookTitle}</td><td><span className={`badge ${item.type === 'Borrow' ? 'badge-borrow' : 'badge-good'}`}>{item.type}</span></td><td>{item.amount}</td><td>{item.member}</td><td>{item.date}</td></tr>)}</tbody></table></div>; }
function Users({ users, saveUser, deleteUser }) {
  const blank = { name: '', membershipId: '', email: '', role: 'Member' }; const [form, setForm] = useState(blank); const [editing, setEditing] = useState(false); const [search, setSearch] = useState(''); const [message, setMessage] = useState('');
  const update = e => setForm({ ...form, [e.target.name]: e.target.value });
  const submit = e => { e.preventDefault(); if (!form.name.trim() || !form.membershipId.trim() || !form.email.trim()) { setMessage('Please complete every field.'); return; } if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) { setMessage('Enter a valid email address.'); return; } const result = saveUser({ ...form, name: form.name.trim() }); if (result) { setMessage(result); return; } setMessage('User saved successfully.'); setForm(blank); setEditing(false); };
  const filtered = users.filter(user => `${user.name} ${user.membershipId} ${user.email} ${user.role}`.toLowerCase().includes(search.toLowerCase()));
  return <main className="content"><PageTitle eyebrow="PEOPLE" title="User management" description="Manage library members and administrator accounts." />
    <section className="panel form-panel"><div className="panel-heading"><div><h2>{editing ? 'Update user' : 'Add a library user'}</h2><p className="muted">Give each member a unique membership ID.</p></div>{editing && <button className="button button-outline" onClick={() => { setForm(blank); setEditing(false); setMessage(''); }}>Cancel edit</button>}</div><form className="book-form" onSubmit={submit}><label>Full name *<input name="name" value={form.name} onChange={update} required /></label><label>Membership ID *<input name="membershipId" value={form.membershipId} onChange={update} required /></label><label>Email address *<input type="email" name="email" value={form.email} onChange={update} required /></label><label>Role<select name="role" value={form.role} onChange={update}><option>Member</option><option>Admin</option></select></label><div className="form-submit"><button className="button button-primary">{editing ? 'Save changes' : '＋ Add user'}</button></div></form>{message && <p className={message.includes('successfully') ? 'success-message' : 'error'}>{message}</p>}<p className="login-note">For this coursework demo, a member can sign in using their email as username and membership ID as password. Do not use real sensitive data.</p></section>
    <section className="panel"><div className="panel-heading list-heading"><div><h2>Library users <span className="count-pill">{users.length}</span></h2><p className="muted">Update user details or remove accounts.</p></div><input className="search-input" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search users..." /></div><div className="table-wrap"><table><thead><tr><th>Name</th><th>Membership ID</th><th>Email</th><th>Role</th><th>Actions</th></tr></thead><tbody>{filtered.map(user => <tr key={user.id}><td><span className="user-cell"><span className="avatar avatar-table">{user.name.charAt(0).toUpperCase()}</span><strong>{user.name}</strong></span></td><td>{user.membershipId}</td><td>{user.email}</td><td><span className={`badge ${user.role === 'Admin' ? 'badge-admin' : 'badge-good'}`}>{user.role}</span></td><td><div className="row-actions"><button className="mini-button" onClick={() => { setForm({ ...user }); setEditing(true); setMessage(''); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>Edit</button><button className="mini-button danger-text" onClick={() => deleteUser(user.id)}>Delete</button></div></td></tr>)}</tbody></table>{!filtered.length && <Empty text="No matching users found." />}</div></section>
  </main>;
}
function Empty({ text }) { return <div className="empty-state"><span>♡</span><p>{text}</p></div>; }

export default App;

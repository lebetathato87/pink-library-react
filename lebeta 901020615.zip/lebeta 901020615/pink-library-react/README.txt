PINK COMMUNITY LIBRARY - REACT ASSIGNMENT

Requirements included:
- React components, useState and useEffect hooks
- React Router pages: Login, Dashboard, Books, Transactions, Users
- Local Storage for books, users and transaction history
- Add, update, delete and search books
- Track quantity and highlight books with fewer than 2 copies
- Add stock and borrow stock with quantity validation
- Transaction history with date/time, book, type, amount and member
- Add, update, delete and search users; unique email and membership ID validation
- Pink responsive CSS design

HOW TO RUN
1. Install Node.js if it is not already installed.
2. Open this project folder in VS Code.
3. Open Terminal > New Terminal.
4. Run: npm install
5. Run: npm run dev
6. Open the local address printed by Vite in your browser.

DEMO ADMIN LOGIN
Username: admin
Password: library123

MEMBER DEMO LOGIN
After adding a member under Users, sign in with their email as the username and their membership ID as the password.

NOTE
This is a coursework demonstration. Data is stored in the browser's Local Storage, and the login is not production security. A real application should use server-side authentication, password hashing and server-side role/permission checks.
